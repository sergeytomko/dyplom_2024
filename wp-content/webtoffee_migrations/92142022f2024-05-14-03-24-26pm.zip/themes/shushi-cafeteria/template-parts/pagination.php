<?php
	the_posts_pagination( array(
		'prev_text' => esc_html__( 'Previous page', 'shushi-cafeteria' ),
		'next_text' => esc_html__( 'Next page', 'shushi-cafeteria' ),
	) );