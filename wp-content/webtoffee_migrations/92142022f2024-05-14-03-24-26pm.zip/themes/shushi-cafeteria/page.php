<?php get_header(); ?>

<div id="content">
  <div class="feature-header">
      <div class="feature-post-thumbnail">
         <?php
            if ( has_post_thumbnail() ) :
              the_post_thumbnail();
            else:
              ?>
              <div class="slider-alternate">
                <img src="<?php echo get_stylesheet_directory_uri() . '/assets/images/banner.png'; ?>">
              </div>
              <?php
            endif;
          ?>
        <h1 class="post-title feature-header-title"><?php the_title(); ?></h1>
         <?php if ( get_theme_mod('shushi_cafeteria_breadcrumb_enable',true) ) : ?>
          <div class="bread_crumb text-center">
            <?php shushi_cafeteria_breadcrumb();  ?>
          </div>
        <?php endif; ?>
      </div>
  </div>
  <div class="container">
    <div class="row">
      <div class="col-lg-8 col-md-8 mt-5">
        <?php
          while ( have_posts() ) :
            the_post();
            get_template_part( 'template-parts/content', 'page');

            wp_link_pages(
              array(
                'before' => '<div class="shushi-cafeteria-pagination">',
                'after' => '</div>',
                'link_before' => '<span>',
                'link_after' => '</span>'
              )
            );
            comments_template();
          endwhile;
        ?>
      </div>
      <div class="col-lg-4 col-md-4">
        <?php get_sidebar(); ?>
      </div>
    </div>
  </div>
</div>

<?php get_footer(); ?>