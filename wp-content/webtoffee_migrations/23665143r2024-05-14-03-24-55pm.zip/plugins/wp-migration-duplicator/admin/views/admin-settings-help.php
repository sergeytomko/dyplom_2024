<?php
if ( ! defined( 'WPINC' ) ) {
    die;
}

?>
<div class="wf-tab-content" data-id="<?php echo esc_attr($target_id);?>">

</div>